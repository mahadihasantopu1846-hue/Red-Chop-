import 'package:flutter/material.dart';

void main() => runApp(const AdminApp());

class AdminApp extends StatelessWidget {
  const AdminApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'RED CHOP Admin',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE50914)), useMaterial3: true),
    home: const AdminHome(),
  );
}

class AdminHome extends StatefulWidget {
  const AdminHome({super.key});
  @override
  State<AdminHome> createState() => _AdminHomeState();
}

class _AdminHomeState extends State<AdminHome> {
  final orders = [
    {'id':'RC-1001','customer':'Sample Customer','items':'2 items','total':'৳320','status':'Pending'},
    {'id':'RC-1002','customer':'Sample Customer','items':'3 items','total':'৳640','status':'Preparing'},
    {'id':'RC-1003','customer':'Sample Customer','items':'1 item','total':'৳150','status':'Out for Delivery'},
  ];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white, title: const Text('RED CHOP • ADMIN')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Order Overview', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 12),
      const Row(children: [
        Expanded(child: _StatCard(label:'New Orders', value:'08', icon:Icons.notifications_active)),
        SizedBox(width:8),
        Expanded(child: _StatCard(label:'Today Sales', value:'৳4,850', icon:Icons.payments)),
      ]),
      const SizedBox(height: 20),
      const Text('Recent Orders', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      ...orders.map((o) => Card(child: ListTile(
        title: Text(o['id']!, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${o['customer']} • ${o['items']} • ${o['total']}'),
        trailing: PopupMenuButton<String>(
          initialValue: o['status'],
          onSelected: (v) => setState(() => o['status'] = v),
          itemBuilder: (_) => ['Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled']
            .map((s) => PopupMenuItem(value:s, child:Text(s))).toList(),
          child: Chip(label: Text(o['status']!)),
        ),
      ))),
      const SizedBox(height: 12),
      const Text('Prototype only: orders shown here are sample data. Connect Firebase Auth, Firestore and server-side authorization before operational use.',
        style: TextStyle(color: Colors.black54)),
    ]),
  );
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const _StatCard({required this.label, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: const Color(0xFFE50914)),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(color: Colors.black54)),
    ])),
  );
}
