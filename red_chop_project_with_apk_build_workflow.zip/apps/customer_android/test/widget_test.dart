import 'package:flutter_test/flutter_test.dart';
import 'package:red_chop_customer/main.dart';

void main() {
  testWidgets('RED CHOP customer app renders brand title', (tester) async {
    await tester.pumpWidget(const RedChopApp());
    expect(find.text('RED CHOP'), findsOneWidget);
  });
}
