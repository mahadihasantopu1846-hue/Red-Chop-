import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() => runApp(const RedChopApp());

class RedChopApp extends StatefulWidget {
  const RedChopApp({super.key});
  @override
  State<RedChopApp> createState() => _RedChopAppState();
}

class _RedChopAppState extends State<RedChopApp> {
  Locale _locale = const Locale('bn');
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'RED CHOP',
    locale: _locale,
    supportedLocales: const [Locale('bn'), Locale('en')],
    localizationsDelegates: const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE50914), brightness: Brightness.light),
      scaffoldBackgroundColor: const Color(0xFFF8F8F8),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.black, foregroundColor: Colors.white),
      useMaterial3: true,
    ),
    home: CustomerHome(
      locale: _locale,
      onLocaleChanged: (v) => setState(() => _locale = v),
    ),
  );
}

class Product {
  final String id, nameBn, nameEn, category;
  final int price;
  final String description;
  const Product(this.id, this.nameBn, this.nameEn, this.category, this.price, this.description);
  String name(Locale locale) => locale.languageCode == 'bn' ? nameBn : nameEn;
}

const products = <Product>[
  Product('burger_crispy', 'ক্রিসপি চিকেন বার্গার', 'Crispy Chicken Burger', 'Burger', 150, 'Crispy chicken burger'),
  Product('burger_naga', 'নাগা বার্গার', 'Naga Burger', 'Burger', 170, 'Spicy naga sauce'),
  Product('burger_bbq_cheese', 'BBQ চিজ বার্গার', 'BBQ Cheese Burger', 'Burger', 200, 'BBQ chicken and cheese'),
  Product('burger_chicken_cheese', 'চিকেন চিজ বার্গার', 'Chicken Cheese Burger', 'Burger', 180, 'Chicken and cheese'),
  Product('burger_student', 'স্টুডেন্ট বার্গার', 'Student Burger', 'Burger', 100, 'Student favourite'),
  Product('burger_double', 'ডাবল লেয়ার বার্গার', 'Double Layer Burger', 'Burger', 240, 'Double layer burger'),
  Product('french_fries', 'ফ্রেঞ্চ ফ্রাই ১:২', 'French Fry 1:2', 'Appetizer', 150, 'Crispy french fries'),
  Product('mexican_nachos', 'মেক্সিকান নাচোস ১:১', 'Mexican Nachos 1:1', 'Appetizer', 150, 'Mexican-style nachos'),
  Product('tower_nachos', 'স্পেশাল টাওয়ার নাচোস ১:৪', 'Special Tower Nachos 1:4', 'Appetizer', 380, 'Sharing nachos tower'),
  Product('chicken_ball', 'চিকেন বল ১০ পিস', 'Chicken Ball (10 pcs)', 'Appetizer', 110, 'Ten pieces'),
  Product('crispy_fry_1', 'ক্রিসপি চিকেন ফ্রাই ১ পিস', 'Crispy Chicken Fry (1 pc)', 'Appetizer', 80, 'One piece'),
  Product('crispy_fry_4', 'ক্রিসপি চিকেন ফ্রাই ৪ পিস', 'Crispy Chicken Fry (4 pcs)', 'Appetizer', 330, 'Four pieces'),
  Product('sandwich_regular', 'রেগুলার চিকেন স্যান্ডউইচ', 'Regular Chicken Sandwich', 'Sandwich', 160, 'Chicken sandwich'),
  Product('sandwich_naga', 'নাগা চিকেন স্যান্ডউইচ', 'Naga Chicken Sandwich', 'Sandwich', 180, 'Spicy naga chicken'),
  Product('sandwich_bbq', 'BBQ চিকেন চিজ স্যান্ডউইচ', 'BBQ Chicken Cheese Sandwich', 'Sandwich', 200, 'BBQ chicken and cheese'),
  Product('meat_bbq', 'চিকেন BBQ মিট বক্স', 'Chicken BBQ Meat Box', 'Meat Box', 180, 'BBQ chicken box'),
  Product('meat_naga', 'নাগা মিট বক্স', 'Naga Meat Box', 'Meat Box', 170, 'Spicy meat box'),
  Product('meat_classic', 'ক্লাসিক মিট বক্স', 'Classic Meat Box', 'Meat Box', 150, 'Classic meat box'),
  Product('chowmein_special', 'স্পেশাল চাউমিন ১:১', 'Special Chowmein 1:1', 'Chowmein', 180, 'Special chowmein'),
  Product('chowmein_chicken', 'চিকেন চাউমিন', 'Chicken Chowmein', 'Chowmein', 150, 'Chicken chowmein'),
  Product('chowmein_sausage', 'চিকেন সসেজ চাউমিন', 'Chicken Sausage Chowmein', 'Chowmein', 170, 'Chicken sausage chowmein'),
  Product('seafood_combo', 'সি ফুড মিক্সড কম্বো', 'Sea Food Mixed Combo', 'Combo', 640, 'Crab Masala, Naan, Fried Rice, Chilli Chicken, Vegetables, Chicken Sandwich, Mimi Nachos and French Fry'),
];

class CustomerHome extends StatefulWidget {
  final Locale locale;
  final ValueChanged<Locale> onLocaleChanged;
  const CustomerHome({super.key, required this.locale, required this.onLocaleChanged});
  @override
  State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  final Map<String, int> cart = {};
  String category = 'All';
  String search = '';
  bool get bn => widget.locale.languageCode == 'bn';
  int get total => products.fold(0, (sum, p) => sum + p.price * (cart[p.id] ?? 0));
  int get count => cart.values.fold(0, (sum, q) => sum + q);

  @override
  Widget build(BuildContext context) {
    final filtered = products.where((p) =>
      (category == 'All' || p.category == category) &&
      ('${p.nameBn} ${p.nameEn}'.toLowerCase().contains(search.toLowerCase()))).toList();
    return Scaffold(
      appBar: AppBar(
        title: const Text('RED CHOP', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        actions: [
          TextButton(onPressed: () => widget.onLocaleChanged(Locale(bn ? 'en' : 'bn')),
            child: Text(bn ? 'EN' : 'বাংলা', style: const TextStyle(color: Colors.white))),
          IconButton(onPressed: _showCart, icon: Badge(label: Text('$count'), child: const Icon(Icons.shopping_cart_outlined))),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(20)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('YOUR FOOD. YOUR MOOD.', style: TextStyle(color: Color(0xFFFF3030), fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(bn ? 'আজ কী খেতে চান?' : 'What are you craving today?',
                style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Text(bn ? 'সুস্বাদু খাবার, আপনার পছন্দে।' : 'Delicious food, made for your mood.',
                style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 16),
          TextField(
            onChanged: (v) => setState(() => search = v),
            decoration: InputDecoration(
              prefixIcon: const Icon(Icons.search),
              hintText: bn ? 'খাবার খুঁজুন' : 'Search food',
              filled: true, fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(height: 42, child: ListView(
            scrollDirection: Axis.horizontal,
            children: ['All', 'Burger', 'Appetizer', 'Sandwich', 'Meat Box', 'Chowmein', 'Combo'].map((c) =>
              Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(
                label: Text(c == 'All' ? (bn ? 'সব' : 'All') : c),
                selected: category == c, onSelected: (_) => setState(() => category = c),
                selectedColor: const Color(0xFFFFD8D8),
              ))).toList(),
          )),
          const SizedBox(height: 8),
          Text(bn ? 'আমাদের মেনু' : 'Our Menu', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ...filtered.map((p) => Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 10),
            child: ListTile(
              leading: Container(width: 54, height: 54, decoration: BoxDecoration(color: const Color(0xFFFFE5E5), borderRadius: BorderRadius.circular(12)),
                child: const Icon(Icons.restaurant, color: Color(0xFFE50914))),
              title: Text(p.name(widget.locale), style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('৳${p.price}'),
              trailing: IconButton(
                onPressed: () => setState(() => cart[p.id] = (cart[p.id] ?? 0) + 1),
                icon: const Icon(Icons.add_circle, color: Color(0xFFE50914), size: 30),
              ),
            ),
          )),
        ],
      ),
      bottomNavigationBar: count == 0 ? null : SafeArea(
        child: Padding(padding: const EdgeInsets.all(12), child: FilledButton(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFE50914), padding: const EdgeInsets.all(16)),
          onPressed: _showCart,
          child: Text(bn ? 'কার্ট ($count) • ৳$total' : 'Cart ($count) • ৳$total'),
        )),
      ),
    );
  }

  void _showCart() {
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (ctx) => StatefulBuilder(
      builder: (ctx, setSheet) => SafeArea(child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(bn ? 'আপনার কার্ট' : 'Your Cart', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (count == 0) Text(bn ? 'কার্ট খালি' : 'Your cart is empty'),
          ...products.where((p) => (cart[p.id] ?? 0) > 0).map((p) => ListTile(
            title: Text(p.name(widget.locale)),
            subtitle: Text('৳${p.price} × ${cart[p.id]}'),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              IconButton(onPressed: () { setState(() { final n = (cart[p.id] ?? 0) - 1; if (n <= 0) { cart.remove(p.id); } else { cart[p.id] = n; } }); setSheet(() {}); this.setState(() {}); }, icon: const Icon(Icons.remove_circle_outline)),
              Text('${cart[p.id] ?? 0}'),
              IconButton(onPressed: () { setState(() => cart[p.id] = (cart[p.id] ?? 0) + 1); setSheet(() {}); this.setState(() {}); }, icon: const Icon(Icons.add_circle_outline)),
            ]),
          )),
          const Divider(),
          ListTile(title: Text(bn ? 'সাবটোটাল' : 'Subtotal'), trailing: Text('৳$total')),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: FilledButton(
            onPressed: count == 0 ? null : () {
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(bn
                ? 'ডেমো: চেকআউটের আগে ব্যাকএন্ড সংযুক্ত করতে হবে।'
                : 'Demo: connect the backend before checkout.')));
            },
            child: Text(bn ? 'চেকআউট (ডেমো)' : 'Checkout (demo)'),
          )),
        ]),
      )),
    ));
  }
}
