import React from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const sampleOrders = [
  {id:'RC-1001', customer:'Sample Customer', items:'Crispy Chicken Burger × 2', total:'৳300', status:'Pending'},
  {id:'RC-1002', customer:'Sample Customer', items:'Sea Food Mixed Combo × 1', total:'৳640', status:'Preparing'},
  {id:'RC-1003', customer:'Sample Customer', items:'Mexican Nachos × 1', total:'৳150', status:'Out for Delivery'},
];
function App() {
  const [orders, setOrders] = React.useState(sampleOrders);
  const [tab, setTab] = React.useState('Orders');
  const [search, setSearch] = React.useState('');
  const visible = orders.filter(o => `${o.id} ${o.customer} ${o.items}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><span className="brand-mark">RC</span><div><strong>RED CHOP</strong><small>ADMIN CONSOLE</small></div></div>
      {['Overview','Orders','Menu','Offers','Delivery Rules','Reports','Settings'].map(x =>
        <button key={x} className={tab===x?'nav active':'nav'} onClick={()=>setTab(x)}>{x}</button>)}
      <div className="sidebar-foot">Starter dashboard<br/>Connect Firebase before production</div>
    </aside>
    <main className="main">
      <header><div><p className="eyebrow">RESTAURANT MANAGEMENT</p><h1>{tab}</h1></div><span className="status">● Prototype mode</span></header>
      {tab==='Overview' || tab==='Orders' ? <>
        <section className="stats">
          <div className="stat"><span>New orders</span><strong>{orders.filter(o=>o.status==='Pending').length.toString().padStart(2,'0')}</strong><small>Sample data</small></div>
          <div className="stat"><span>Active orders</span><strong>{orders.filter(o=>!['Delivered','Cancelled'].includes(o.status)).length.toString().padStart(2,'0')}</strong><small>Not live</small></div>
          <div className="stat"><span>Sample sales</span><strong>৳1,090</strong><small>Illustrative only</small></div>
        </section>
        <section className="panel">
          <div className="panel-head"><div><h2>Recent orders</h2><p>Review and update order status</p></div><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search order or item…"/></div>
          <div className="table-wrap"><table><thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th></tr></thead>
          <tbody>{visible.map(o=><tr key={o.id}><td className="order-id">{o.id}</td><td>{o.customer}</td><td>{o.items}</td><td>{o.total}</td><td><select value={o.status} onChange={e=>setOrders(old=>old.map(x=>x.id===o.id?{...x,status:e.target.value}:x))}>{['Pending','Confirmed','Preparing','Out for Delivery','Delivered','Cancelled'].map(s=><option key={s}>{s}</option>)}</select></td></tr>)}</tbody></table></div>
          <p className="notice">Demo data only. Changes stay in this browser session and are not saved to a server.</p>
        </section>
      </> : <section className="panel placeholder"><div className="placeholder-icon">✦</div><h2>{tab} module</h2><p>This screen is scaffolded for the next implementation step. Connect Firebase and implement role-based access before use.</p></section>}
    </main>
  </div>;
}
createRoot(document.getElementById('root')).render(<App/>);
