# RED CHOP — Monorepo Starter

A practical starter scaffold for:
- `apps/customer_android`: Flutter customer app (Bangla/English, menu, cart starter)
- `apps/admin_android`: Flutter admin app starter
- `apps/web_dashboard`: React + Vite web admin dashboard starter
- `backend/functions`: Firebase Cloud Functions (TypeScript) starter
- `firebase`: Firestore rules and indexes

## Important
This is a **starter codebase**, not a production-ready ordering system. Firebase project credentials, payment gateway credentials, restaurant location, delivery pricing, privacy policy, and production testing are not included. Do not accept real payments until server-side payment verification and provider webhook handling are implemented and tested.

## Requirements
- Flutter SDK (stable)
- Node.js LTS and npm
- Firebase CLI (`npm install -g firebase-tools`)
- A Firebase project

## Project layout
```text
red_chop_project/
  apps/
    customer_android/
    admin_android/
    web_dashboard/
  backend/functions/
  firebase/
  firebase.json
  .firebaserc.example
```

## 1. Customer Android app
```bash
cd apps/customer_android
flutter pub get
flutter run
```
The starter includes bilingual strings, RED CHOP black/red styling, sample menu data, and a local cart prototype. The menu is currently sample/local data; connect it to Firestore before production.

## 2. Admin Android app
```bash
cd apps/admin_android
flutter pub get
flutter run
```
This is a role-aware UI scaffold. Add Firebase Authentication and enforce admin roles using trusted backend claims/rules before real use.

## 3. Web dashboard
```bash
cd apps/web_dashboard
npm install
npm run dev
```
The web dashboard is a responsive starter UI with sample orders. Connect Firebase Auth/Firestore and enforce access control before use.

## 4. Firebase backend
```bash
cd backend/functions
npm install
npm run build
```
Deploy only after configuring your Firebase project:
```bash
firebase login
cp .firebaserc.example .firebaserc
# edit .firebaserc with your actual project id
firebase deploy --only firestore:rules,functions
```

## Security checklist before production
- Use Firebase Authentication; do not trust client-supplied user IDs or roles.
- Set admin custom claims only from a trusted server/admin process.
- Validate product availability and prices on the server at checkout.
- Calculate delivery fee on the server using configured restaurant coordinates and approved routing/distance policy.
- Create orders transactionally; prevent duplicate checkout submissions with an idempotency key.
- Integrate a payment provider and verify payment status server-side/webhook-side.
- Keep secrets in Secret Manager / environment configuration, never in source control.
- Test Firestore rules with the Firebase Emulator Suite.
- Add privacy policy, terms, refund/cancellation rules, and Play Store assets.


## Build APKs using GitHub Actions (no Flutter installation on your phone required)

This repository includes `.github/workflows/build-android.yml`. To use it:
1. Create a GitHub repository and upload/push the contents of this folder.
2. Open the repository's **Actions** tab.
3. Choose **Build RED CHOP Android APKs** and select **Run workflow**.
4. Wait for both jobs to finish successfully.
5. Open the completed workflow run and download the artifacts:
   - `red-chop-customer-apk`
   - `red-chop-admin-apk`
6. Extract the downloaded artifact ZIP on your phone and tap `app-release.apk` to install.

The APKs are starter prototypes, not production-connected apps. The customer checkout is a demo, and Firebase, live orders, delivery fees, online payment, and production security still require configuration. GitHub account and repository upload are required for this build path.
