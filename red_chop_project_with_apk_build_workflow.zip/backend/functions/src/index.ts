import { onCall, HttpsError } from "firebase-functions/v2/https";
import { initializeApp } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";
import { randomUUID } from "crypto";

initializeApp();
const db = getFirestore();

type CartItemInput = { productId: string; quantity: number };
type CreateOrderInput = {
  items: CartItemInput[];
  addressId: string;
  paymentMethod: "cash_on_delivery" | "online";
  idempotencyKey: string;
  couponCode?: string;
};

// Starter checkout function. Payment gateway and delivery distance service must be configured
// before production. Client never supplies trusted product prices or final totals.
export const createOrder = onCall({ enforceAppCheck: false }, async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Please sign in first.");
  const input = request.data as CreateOrderInput;
  if (!input || !Array.isArray(input.items) || input.items.length < 1 || input.items.length > 50) {
    throw new HttpsError("invalid-argument", "Cart items are required.");
  }
  if (!input.addressId || !input.idempotencyKey) {
    throw new HttpsError("invalid-argument", "Address and idempotency key are required.");
  }
  if (!["cash_on_delivery", "online"].includes(input.paymentMethod)) {
    throw new HttpsError("invalid-argument", "Unsupported payment method.");
  }
  for (const item of input.items) {
    if (!item.productId || !Number.isInteger(item.quantity) || item.quantity < 1 || item.quantity > 25) {
      throw new HttpsError("invalid-argument", "Invalid cart item.");
    }
  }

  const uid = request.auth.uid;
  const idemRef = db.collection("checkoutKeys").doc(`${uid}_${input.idempotencyKey}`);
  const addressRef = db.collection("addresses").doc(input.addressId);
  const products = await Promise.all(input.items.map(i => db.collection("products").doc(i.productId).get()));
  const address = await addressRef.get();
  if (!address.exists || address.data()?.userId !== uid) {
    throw new HttpsError("permission-denied", "Address does not belong to this account.");
  }
  if (products.some(p => !p.exists || p.data()?.isAvailable !== true)) {
    throw new HttpsError("failed-precondition", "One or more products are unavailable.");
  }

  let subtotal = 0;
  const itemsSnapshot = input.items.map((item, idx) => {
    const product = products[idx].data()!;
    const price = Number(product.price);
    if (!Number.isFinite(price) || price < 0) throw new HttpsError("failed-precondition", "Invalid product price.");
    subtotal += price * item.quantity;
    return {
      productId: item.productId,
      nameBn: String(product.nameBn ?? ""),
      nameEn: String(product.nameEn ?? ""),
      unitPrice: price,
      quantity: item.quantity,
      lineTotal: price * item.quantity
    };
  });

  // Placeholder policy: real delivery fee calculation must use configured restaurant location
  // and a validated distance/routing service. Do not deploy this zero-fee placeholder to production.
  const deliveryFee = 0;
  const discount = 0; // Validate coupon on the server before enabling discounts.
  const total = subtotal - discount + deliveryFee;
  const orderRef = db.collection("orders").doc();
  const paymentRef = db.collection("payments").doc();
  const orderNumber = `RC-${Date.now().toString().slice(-8)}-${randomUUID().slice(0, 4).toUpperCase()}`;

  await db.runTransaction(async tx => {
    const existing = await tx.get(idemRef);
    if (existing.exists) return;
    tx.create(orderRef, {
      orderNumber, userId: uid, itemsSnapshot,
      subtotal, discount, deliveryFee, total,
      addressSnapshot: address.data(),
      paymentMethod: input.paymentMethod,
      paymentStatus: input.paymentMethod === "cash_on_delivery" ? "pending_cash" : "pending",
      orderStatus: "pending",
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp()
    });
    tx.create(paymentRef, {
      orderId: orderRef.id, userId: uid, provider: input.paymentMethod,
      amount: total, status: input.paymentMethod === "cash_on_delivery" ? "pending_cash" : "pending",
      createdAt: FieldValue.serverTimestamp()
    });
    tx.create(idemRef, { orderId: orderRef.id, createdAt: FieldValue.serverTimestamp() });
  });

  const key = await idemRef.get();
  return { orderId: key.data()?.orderId ?? orderRef.id, orderNumber, message: "Order request processed." };
});

// Admin callable: custom claim `admin: true` must be assigned by a trusted process.
export const updateOrderStatus = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Admin access required.");
  }
  const { orderId, status } = request.data as { orderId: string; status: string };
  const allowed = ["pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"];
  if (!orderId || !allowed.includes(status)) throw new HttpsError("invalid-argument", "Invalid order status.");
  const ref = db.collection("orders").doc(orderId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Order not found.");
  await ref.update({ orderStatus: status, updatedAt: FieldValue.serverTimestamp() });
  return { ok: true };
});
