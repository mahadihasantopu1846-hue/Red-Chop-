## Backend implementation notes

`createOrder` demonstrates server-side product price lookup, address ownership validation, and an idempotency key. It deliberately uses a zero delivery fee placeholder and does not complete online payments. Do not use it for real orders until delivery pricing, coupon validation, payment gateway initiation/webhooks, App Check, rate limiting, and comprehensive tests are implemented.

Create admin custom claims only from a trusted administrative environment. Never let a client set its own `admin` claim.
